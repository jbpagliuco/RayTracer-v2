Each image has an associated .stats file with it (just a text file), which describes the render times, except the instancing one.

I've been rewriting my engine code to clean it up, and to change a few things, 
so the current iteration doesn't have meshs implemented. So, the instancing pictures are
older. I've included two pictures for instancing,
the unfinshed one clearly shows the grass mesh is instanced, but since it's unfinished, I don't have 
render times (its unfinished because my computer shut off while it was rendering when I was sleeping).
The other image (of the same scene, just a different camera angle) has its render times. 